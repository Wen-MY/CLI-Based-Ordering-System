package DataList;
import java.util.List;

public interface IObjectData {
	public List<?> record();
	public Object[] getArray();
	public void defaultObject();
}
